const mongoose = require("mongoose");

const ProductSchema = new mongoose.Schema({
    title: {
        type: String,
        required: [true, "Title Required"],
        minlength: [3, " Title needs to be 3 characters long"]
    },

    price: {
        type: Number,
        required: [true, "Nothing is free holmes"],
        min: [1, "Minimum is 1!"]
    },

    description: {
        type: String,
        required: [true, "Description Required"],
        minlength: [3, " Description needs to be 3 characters long"]
    }
},
    { timestamps: true }
);

const Product = mongoose.model("Product", ProductSchema);

module.exports = Product;