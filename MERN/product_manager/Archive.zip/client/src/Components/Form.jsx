import React, {useState,useEffect}from 'react';
import axios from 'axios';

export default function Form(props) {
    const[name, setName] = useState("");
    const[type, setType] = useState("");
    const[description, setDescription] = useState("");
    const [err, setErr] = useState("");


    const formHandler = (e) =>{
        e.preventDefault();
        axios.post('http://localhost:8000/api/products/new',{
            name,
            type,
            description})
        .then(res=>{
            console.log(res);
            if(res.data.error){
                setErr(res.data.error.errors)
            }
            // setName("")
            // setType("")
            // setDescription("")
        })
        .catch(err => {console.log(err.res.data.err.errors.description)})

    }

    return (
        <div>
            <div className=''>
                <h1>Pet Shelter</h1>
            </div>
            <form onSubmit={formHandler}>
                <div className='container mt-3 d-flex flex-column w-25'>
                    <span>{err.name && err.name.message}</span>
                    <input type="text" placeholder='name' onChange={(e) => setName(e.target.value)} value={name} name="name"/><br />

                    <span>{err.type && err.type.message}</span>
                    <input type="number" placeholder='type' onChange={(e) => setType(e.target.value)} value={type} name="type" /><br />

                    <span>{err.description && err.description.message}</span>
                    <input type="text" placeholder='description' onChange={(e) => setDescription(e.target.value)} value={description} name="description"/><br />

                    <button type='submit'>Create</button>
                </div>
            </form>
        </div>)
}