import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Link } from 'react-router-dom';

const AllPets = (props) => {
    const [pets, setPetsData] = useState([]);


    useEffect(() => {
        axios.get('http://localhost:8000/api/pets')
            .then(res => {
                console.log(res);
                setPetsData(res.data);
            })
            .catch(err => {
                console.log(err);
                setPetsData("")
            })

    }, [])

    const deletePet = (petID) => {
        axios.delete('http://localhost:8000/api/pets/delete/' + petID)
            .then(res => {
                removeFromDom(petID)
            })
            .catch(err => console.error(err));
    }
    const removeFromDom = petID => {
        setPetsData(pets.filter(pet => pet._id !== petID));
    }

    return (
        <div>
            <h2>All Pets</h2>
            {
                pets.map((pet, i) => {
                    return <div key={i}><span > <Link to={`/api/pets/${pet._id}`}> {pet.title}</Link></span> 
                    
                    <Link to={`/api/pets/update/${pet._id}`}><button>Edit</button></Link>

                    <button onClick={(e)=>{deletePet(pet._id)}}>Delete</button></div>
                })
            }
        </div>
                )
}
export default AllPets;