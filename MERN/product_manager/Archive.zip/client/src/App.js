import './App.css';
import Form from './Components/Form';
import AllPets from './Components/AllPets';
import Single from './Views/Single';
import Update from './Views/Update';
import { BrowserRouter, Switch, Route } from "react-router-dom";
function App() {
  return (
    <div className="App">
      <BrowserRouter>
        <Switch>
          <Route exact path="/">
            <Form />
            <AllPets />
          </Route>
          <Route exact path="/api/pets/:_id">
            <Single/>
          </Route>
          <Route exact path="/api/pets/update/:_id">
            <Update/>
          </Route>
        </Switch>
      </BrowserRouter>
    </div>
  );
}

export default App;