package com.zoo;

public class zooTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Gorilla magilla = new Gorilla(100);
		magilla.throwSomething();
		magilla.throwSomething();
		magilla.throwSomething();
		magilla.eatBananas();
		magilla.eatBananas();
		magilla.climb();
		magilla.displayEnergy();
		
	}
}
