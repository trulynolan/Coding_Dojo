package com.zoo;

public class batTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Bat michaelBatson = new Bat(300);
		michaelBatson.attackTown();
		michaelBatson.attackTown();
		michaelBatson.attackTown();
		michaelBatson.eatHumans();
		michaelBatson.eatHumans();
		michaelBatson.fly();
		michaelBatson.fly();
		michaelBatson.displayEnergy();
		
	}

}
